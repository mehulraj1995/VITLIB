package com.example.databaseattempt1;

public class Tasks {

    private int _id;
    private String _taskname;
    private String _tasknumber;
    public void Tasks(){

    }
    public Tasks(String taskname,String tasknumber){
        this._taskname = taskname;
        this._tasknumber=tasknumber;
    }

    public int get_id() {
        return _id;
    }

    public String get_taskname() {
        return _taskname;
    }

    public String get_tasknumber() {
        return _tasknumber;
    }

    public void set_id(int _id) {
        this._id = _id;
    }

    public void set_taskname(String _taskname) {
        this._taskname = _taskname;
    }
    public void set_tasknumber(String _tasknumber){
        this._tasknumber=_tasknumber;
    }
}
