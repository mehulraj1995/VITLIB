package com.example.databaseattempt1;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {

    EditText edittext,edit;
    TextView listview1,listview2;
    mydatabasehelper databasehelper,databasehelper1;
    private Object tasks1;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        edittext= (EditText) findViewById(R.id.editTextTask);
        edit=(EditText) findViewById(R.id.editTextnumber);

        listview1= (TextView) findViewById(R.id.oname);
//        listview2= (TextView) findViewById(R.id.onumber);
        databasehelper =new mydatabasehelper(this,null,null,1);
        printdb();
//        databasehelper1=new mydatabasehelper(this,null,null,1 );
//        printdb();
    }
    public void addButtonClicked(View view){
        Tasks tasks= new Tasks(edittext.getText().toString(),edit.getText().toString());
         databasehelper.addTask(tasks);
//        databasehelper1.addTask(tasks1);
        printdb();

    }
    public void removeButtonClicked(View view){
        String input=edittext.getText().toString();
        databasehelper.removetasks(input);
//        databasehelper1.removetasks(input);
        printdb();

    }
    public void printdb(){
        String dbstring = databasehelper.databasetostring();
        listview1.setText(dbstring);

    }


}
