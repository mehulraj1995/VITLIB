package com.example.databaseattempt1;

public class tasks1 {
    private int _id;
    private int _tasknumber;
    public void tasks1(){

    }
    public tasks1(int tasknumber){
        this._tasknumber = tasknumber;
    }

    public int get_id() {
        return _id;
    }

    public int get_tasknumber() {
        return _tasknumber;
    }

    public void set_id(int _id) {
        this._id = _id;
    }

    public void set_taskname(int _tasknumber) {
        this._tasknumber = _tasknumber;
    }
}
