package com.example.vit_lib;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class userlibwork extends AppCompatActivity {
    public Button find1;
    public EditText book1;

    public String str[] ={"bs grewal","thomas calculus","devotion of suspect x","the fault in our stars","electric circuit"};
    public int counter[]={25,24,23,20,15};

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_userlibwork);
        book1=(EditText) findViewById(R.id.bookname);

        //Log.e("Book Name: " , book_name);
        find1=(Button) findViewById(R.id.booksearch);


            book1.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    SharedPreferences booksDB = getSharedPreferences("BooksDB",MODE_PRIVATE);
                    SharedPreferences.Editor prefEditor = booksDB.edit();

                    String book_name = book1.getText().toString();
                    int x = 1;
                    Loop:
                    for (int i = 0; i < 5; i++) {
                        Log.e("Book : ", book_name + " :: " + str[i]);
                        if (book_name.equals(str[i])) {
                            x = 0;
                            prefEditor.putInt("count"+String.valueOf(i+1),booksDB.getInt("count"+String.valueOf(i+1),0)-1);
                            prefEditor.commit();
                            if(counter[i]>0){
                                counter[i]--;
                            }
                            else{
                                x=1;
                                break Loop;
                            }
                            break;
                        }
                    }
                    if (x == 0) {

                        Intent i = new Intent(getApplicationContext(), bookoutput.class);
                        startActivity(i);
                    }
                    else {
                        Toast.makeText(userlibwork.this, "Book not available", Toast.LENGTH_SHORT).show();
                    }
                }
            });


        }
    }

