package com.example.vit_lib;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class libactivity extends AppCompatActivity {
    Button blibrary;
    EditText etUserID, etUserPwd;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_libactivity);

        Toast.makeText(this, "Hello Libararian!!", Toast.LENGTH_SHORT).show();

        getSupportActionBar().setDisplayHomeAsUpEnabled(true);

        initializeComponents();

        executeListeners();

    }

    // <editor-fold default="collapsed" desc="initializeComponents">
    public void initializeComponents(){
        blibrary= findViewById(R.id.liblogin);
        etUserID = findViewById(R.id.editText);
        etUserPwd = findViewById(R.id.editText2);
    }
    // </editor-fold>

    // <editor-fold default="collapsed" desc="executeListerners">
    public void executeListeners(){
        blibrary.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                if(etUserID.getText().toString().equalsIgnoreCase("18BCE1308")
                        && etUserPwd.getText().toString().equals("abc")){
                    Intent i = new Intent(getApplicationContext(),libraryfunctionsactivity.class);
                    startActivity(i);
                }else
                    Toast.makeText(getApplicationContext(), "Wrong LogIn Credentials", Toast.LENGTH_SHORT).show();
            }
        });
    }
    // </editor-fold>
}
