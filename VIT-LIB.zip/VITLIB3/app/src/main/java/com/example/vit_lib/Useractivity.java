package com.example.vit_lib;

import androidx.appcompat.app.AppCompatActivity;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class Useractivity extends AppCompatActivity {

    public Button buser,bnewuser;
    public EditText etUserID, etUserPwd;

    public SharedPreferences userDetails;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_useractivity);


        Toast.makeText(this, "Hello User!!", Toast.LENGTH_SHORT).show();
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);

        initializeComponents();
        executeListeners();
    }

    // <editor-fold default="collapsed" desc="initializeComponents">
    public void initializeComponents(){
        userDetails = getSharedPreferences("UserDetails",MODE_PRIVATE);

        buser=findViewById(R.id.loginuser);
        bnewuser=findViewById(R.id.newuser);
        etUserID = findViewById(R.id.editText3);
        if(userDetails.getBoolean("isSignedIn",false)){
            etUserID.setText(userDetails.getString("user_id","18BCE1201"));
        }
        etUserPwd = findViewById(R.id.editText4);
    }
    // </editor-fold>

    // <editor-fold default="collapsed" desc="executeListerners">
    public void executeListeners(){
        buser.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String u_id, u_pwd;


                u_id = userDetails.getString("user_id","18BCE1201");
                u_pwd = userDetails.getString("user_pwd","error");


                if(etUserID.getText().toString().equalsIgnoreCase(u_id)
                        && etUserPwd.getText().toString().equals(u_pwd)){
                    Intent i = new Intent(getApplicationContext(),userfunctionsactivity.class);
                    startActivity(i);
                }else
                    Toast.makeText(getApplicationContext(), "Wrong Login Credentials!", Toast.LENGTH_SHORT).show();

            }
        });


        bnewuser.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent i = new Intent(getApplicationContext(),newuseractivity.class);
                startActivity(i);
            }
        });
    }
    // </editor-fold>
}
