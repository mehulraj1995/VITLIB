package com.example.vit_lib;

import androidx.appcompat.app.AppCompatActivity;

import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class newuseractivity extends AppCompatActivity {

    public EditText etUserID, etUsername, etPwd;
    public Button btnSignUp;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_newuseractivity);

        Toast.makeText(this, "We Welcome you in the Vit-lib!!", Toast.LENGTH_SHORT).show();
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);

        initializeComponents();
        executeListeners();

    }

    // <editor-fold default="collapsed" desc="initializeComponents">
    public void initializeComponents(){
        etUserID = findViewById(R.id.etUserID);
        etUsername = findViewById(R.id.etUsername);
        etPwd = findViewById(R.id.etPwd);
        btnSignUp = findViewById(R.id.signup);
    }
    // </editor-fold>

    // <editor-fold default="collapsed" desc="executeListerners">
    public void executeListeners(){
        btnSignUp.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String u_name, u_id, u_pwd;
                u_name = etUsername.getText().toString();
                u_id = etUserID.getText().toString();
                u_pwd = etPwd.getText().toString();

                if(u_id.equals("") || u_name.equals("") || u_pwd.equals("")) {
                    Toast.makeText(getApplicationContext(), "Null not acceptable!", Toast.LENGTH_SHORT).show();
                    return;
                }

                SharedPreferences userDetails = getSharedPreferences("UserDetails",MODE_PRIVATE);
                SharedPreferences.Editor prefEditor = userDetails.edit();
                prefEditor.putString("user_name",u_name);
                prefEditor.putString("user_id",u_id);
                prefEditor.putString("user_pwd",u_pwd);
                prefEditor.putBoolean("isSignedIn",true);
                prefEditor.commit();

                SharedPreferences booksDB = getSharedPreferences("BooksDB",MODE_PRIVATE);
                prefEditor = booksDB.edit();
                prefEditor.putString("book1","bs grewal");
                prefEditor.putString("book2","thomas calculus");
                prefEditor.putString("book3","devotion of suspect x");
                prefEditor.putString("book4","the fault in our stars");
                prefEditor.putString("book5","electric circuit");
                prefEditor.putInt("count1",25);
                prefEditor.putInt("count2",24);
                prefEditor.putInt("count3",23);
                prefEditor.putInt("count4",20);
                prefEditor.putInt("count5",15);

                prefEditor.commit();



                finish();
            }
        });
    }
    // </editor-fold>
}
