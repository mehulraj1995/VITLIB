package com.example.vit_lib;

import androidx.appcompat.app.AppCompatActivity;

import android.content.SharedPreferences;
import android.os.Bundle;
import android.util.Log;
import android.widget.ArrayAdapter;
import android.widget.ListView;

public class libwork extends AppCompatActivity {


    ListView lvBooks;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_libwork);

        SharedPreferences booksDB = getSharedPreferences("BooksDB",MODE_PRIVATE);

        lvBooks = findViewById(R.id.lvBooks);
        String[] dbString = new String[5];
        for(int i=1;i<6;i++)
            dbString[i-1] = "Book: "
                    +booksDB.getString("book"+String.valueOf(i),"Error")
                    + "\nNumber of Copies: "
                    + String.valueOf(booksDB.getInt("count"+String.valueOf(i),-1));

        ArrayAdapter<String> adapter = new ArrayAdapter<String>(getApplicationContext(), android.R.layout.simple_list_item_1, dbString);
        lvBooks.setAdapter(adapter);

        Log.e("mehul","bs grewal");

    }
}
