package com.example.vit_lib;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.widget.Toast;

public class bookoutput extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_bookoutput);
        Toast.makeText(this, "You have 10 days to return the book!!", Toast.LENGTH_SHORT).show();
    }
}
