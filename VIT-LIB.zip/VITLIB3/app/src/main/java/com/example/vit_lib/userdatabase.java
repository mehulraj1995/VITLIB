package com.example.vit_lib;

public class userdatabase {

    private int _userid;
    private String _username;
    private String _password;

    public userdatabase(String username,String password,int userid){
        this._userid = userid;
        this._password = password;
        this._username = username;
    }

    public int get_userid() {
        return _userid;
    }

    public String get_password() {
        return _password;
    }

    public String get_username() {
        return _username;
    }

    public void set_password(String _password) {
        this._password = _password;
    }

    public void set_userid(int _userid) {
        this._userid = _userid;
    }

    public void set_username(String _username) {
        this._username = _username;
    }

}
