import android.content.ContentValues;
import android.content.Context;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

import androidx.annotation.Nullable;

import com.example.vit_lib.userdatabase;

public class signupdatabase extends SQLiteOpenHelper {

    private static final int DATABASE_VERSION = 1;
    private static final String DATABASE_NAME = "newusers.db";
    public static final String TABLE_USERS ="users";
    public static final String COLUMN_ID="userid";
    public static final String COLUMN_USERNAME = "username";
    public static final String COLUMN_PASSWORD = "password";

    public signupdatabase(@Nullable Context context, @Nullable String name, @Nullable SQLiteDatabase.CursorFactory factory, int version) {
        super(context, DATABASE_NAME, factory, DATABASE_VERSION);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        String query= " CREATE TABLE " + TABLE_USERS + " ( " + COLUMN_ID + " INTEGER PRIMARY KEY AUTOINCREMENT, " + COLUMN_USERNAME + " TEXT, " + COLUMN_PASSWORD +"TEXT " + ");";
        db.execSQL(query);
    }

    public boolean insertdata(String username, String password, String userid){
        SQLiteDatabase db= this.getWritableDatabase();
        ContentValues contentvalues= new ContentValues();
        contentvalues.put(COLUMN_USERNAME,username);
        contentvalues.put(COLUMN_ID,userid);
        contentvalues.put(COLUMN_PASSWORD,password);
        long result = db.insert(TABLE_USERS,null,contentvalues);
        if(result==-1){
            return false;
        }
        else{
            return true;
        }
    }
    @Override
    public void onUpgrade(SQLiteDatabase db, int i, int i1) {
        db.execSQL("DROP TABLE IF EXISTS "+ TABLE_USERS);
        onCreate(db);
    }
}
